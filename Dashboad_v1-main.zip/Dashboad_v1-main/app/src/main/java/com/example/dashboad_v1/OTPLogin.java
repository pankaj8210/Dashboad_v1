package com.example.dashboad_v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;


public class OTPLogin extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_otp_login, container, false);


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final EditText inputMobile = view.findViewById(R.id.inputMobile);
        Button buttonGetOTP = view.findViewById(R.id.buttonGetOTP);

        final ProgressBar progressBar = view.findViewById(R.id.progressBar);

        buttonGetOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(inputMobile.getText().toString().trim().isEmpty()) {
                    //Toast.makeText(OTPLogin.this, "Enter Mobile", Toast.LENGTH_SHORT).show();
                    Toast.makeText(getContext(), "Enter Mobile", Toast.LENGTH_SHORT).show();
                    return;


                }
//                progressBar.setVisibility(View.VISIBLE);
                buttonGetOTP.setVisibility(View.INVISIBLE);



                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        "+91" + inputMobile.getText().toString(),
                        60,
                        TimeUnit.SECONDS,
                        getActivity(),
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){

                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
//                                progressBar.setVisibility(View.GONE);
                                buttonGetOTP.setVisibility(View.VISIBLE);


                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
//                                progressBar.setVisibility(View.GONE);
                                buttonGetOTP.setVisibility(View.VISIBLE);
                                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();


                            }

                            @Override
                            public void onCodeSent(@NonNull String verificationID, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
//                                progressBar.setVisibility(View.GONE);
                                buttonGetOTP.setVisibility(View.VISIBLE);
                                /*Intent intent = new Intent(getContext(), OTPVerification.class);
                                intent.putExtra("mobile", inputMobile.getText().toString());
                                intent.putExtra("verificationID", verificationID);
                                startActivity(intent);*/

                                Bundle bundle = new Bundle();
                                bundle.putString("mobile",inputMobile.getText().toString());
                                bundle.putString("VerificationID",verificationID);
                                getParentFragment().setArguments(bundle);

                                Toast.makeText(getContext(),"Code Sent", Toast.LENGTH_SHORT).show();

                                NavHostFragment.findNavController(OTPLogin.this)
                                        .navigate(R.id.action_OTPLogin_to_OTPVerification);

                            }
                        }
                );





            }
        });
    }


}